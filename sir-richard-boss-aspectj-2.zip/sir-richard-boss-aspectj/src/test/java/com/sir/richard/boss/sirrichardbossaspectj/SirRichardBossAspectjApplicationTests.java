package com.sir.richard.boss.sirrichardbossaspectj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SirRichardBossAspectjApplicationTests {

	@Test
	void contextLoads() {
	}

}
